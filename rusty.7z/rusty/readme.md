# rusty's fullsize

This is based off the handwired/trackpoint keyboard and generated code from [Keyboard Firmware Builder](https://kbfirmware.com/).

Keyboard Maintainer: 
Hardware Supported (tested): Teensy++ 2.0

Make example for this keyboard (after setting up your build environment):

    make handwired/rusty:default

 ../teensy_loader_cli/teensy_loader_cli -w --mcu=at90usb1286 ./handwired_rusty_default.hex 

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).

https://beta.docs.qmk.fm/features/feature_haptic_feedback for keycodes.

google's most convoluted solenoid keyboard code (probably obsolete because it's not enabled in rules.mk) https://github.com/walkerstop/qmk_firmware/tree/8x/keyboards/kbd8x
